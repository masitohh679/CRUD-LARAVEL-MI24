@extends('template')

@section('title', 'Daftar Produk')

@section('content')
    <h1>Daftar Produk</h1>
    <p><a class="button" href="{{ route('products.create') }}">Tambah Produk</a></p>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($products as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->description ?: '-' }}</td>
                    <td>Rp {{ number_format((float) $product->price, 2, ',', '.') }}</td>
                    <td>{{ $product->stock }}</td>
                    <td>
                        <div class="actions">
                            <a class="button" href="{{ route('products.edit', $product) }}">Ubah</a>
                            <form action="{{ route('products.destroy', $product) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6">Belum ada data produk.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
@endsection
