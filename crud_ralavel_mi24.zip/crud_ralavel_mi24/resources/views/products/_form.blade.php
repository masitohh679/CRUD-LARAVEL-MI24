<label for="name">Nama Produk</label>
<input id="name" name="name" type="text" value="{{ old('name', $product->name ?? '') }}" required maxlength="255">

<label for="description">Deskripsi</label>
<textarea id="description" name="description" rows="4">{{ old('description', $product->description ?? '') }}</textarea>

<label for="price">Harga</label>
<input id="price" name="price" type="number" value="{{ old('price', $product->price ?? '') }}" required min="0" step="0.01">

<label for="stock">Stok</label>
<input id="stock" name="stock" type="number" value="{{ old('stock', $product->stock ?? 0) }}" required min="0" step="1">

<p>
    <button type="submit">Simpan</button>
    <a class="button" href="{{ route('products.index') }}">Kembali</a>
</p>
