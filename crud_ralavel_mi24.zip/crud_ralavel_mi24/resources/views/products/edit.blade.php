@extends('template')

@section('title', 'Ubah Produk')

@section('content')
    <h1>Ubah Produk</h1>
    <form action="{{ route('products.update', $product) }}" method="POST">
        @csrf
        @method('PUT')
        @include('products._form')
    </form>
@endsection
