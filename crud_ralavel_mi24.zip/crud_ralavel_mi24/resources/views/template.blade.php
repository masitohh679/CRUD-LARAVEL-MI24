<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Data Produk')</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; color: #222; }
        nav { padding: 16px 24px; background: #f2f2f2; }
        nav a { color: #222; text-decoration: none; font-weight: bold; }
        main { max-width: 1000px; margin: 24px auto; padding: 0 16px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background: #f7f7f7; }
        label { display: block; margin: 14px 0 6px; }
        input, textarea { box-sizing: border-box; width: 100%; max-width: 560px; padding: 8px; }
        button, .button { display: inline-block; padding: 8px 12px; border: 0; background: #eee; color: #222; text-decoration: none; cursor: pointer; }
        .actions { display: flex; gap: 8px; align-items: center; }
        .actions form { margin: 0; }
        .notice { padding: 10px; background: #e8f5e9; }
        .errors { color: #a00; }
    </style>
</head>
<body>
    <nav><a href="{{ route('products.index') }}">CRUD Produk</a></nav>
    <main>
        @if (session('success'))
            <p class="notice">{{ session('success') }}</p>
        @endif

        @if ($errors->any())
            <div class="errors">
                <p>Periksa kembali data yang dimasukkan:</p>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @yield('content')
    </main>
</body>
</html>
