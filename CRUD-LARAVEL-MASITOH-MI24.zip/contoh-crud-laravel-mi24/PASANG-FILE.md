# Cara memasang file ini ke proyek Laravel

Folder ini hanya berisi file yang dibuat/diubah (bukan seluruh framework).

1. Buat proyek Laravel baru bernama `contoh-crud-laravel-mi24`:
   composer create-project laravel/laravel contoh-crud-laravel-mi24
2. Salin isi folder `app`, `database`, `resources`, `routes` dari zip ini ke proyek tersebut
   (timpa `routes/web.php` jika diminta). Salin juga README.md.
3. Jalankan:
   cd contoh-crud-laravel-mi24
   php artisan migrate
   php artisan serve
4. Upload ke GitHub:
   git init
   git add .
   git commit -m "Latihan 1 CRUD Laravel - Masitoh 2457401026"
   git branch -M main
   git remote add origin https://github.com/USERNAME_KAMU/contoh-crud-laravel-mi24.git
   git push -u origin main
