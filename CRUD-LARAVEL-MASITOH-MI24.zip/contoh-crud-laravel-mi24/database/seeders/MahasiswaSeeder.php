<?php

namespace Database\Seeders;

use App\Models\Mahasiswa;
use Illuminate\Database\Seeder;

class MahasiswaSeeder extends Seeder
{
    public function run(): void
    {
        Mahasiswa::create([
            'nim' => '2457401026',
            'nama' => 'Masitoh',
            'jurusan' => 'Manajemen Informatika',
            'email' => null,
        ]);
    }
}
