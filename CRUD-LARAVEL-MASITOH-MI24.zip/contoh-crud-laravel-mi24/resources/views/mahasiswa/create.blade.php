@extends('layouts.app')
@section('title', 'Tambah Data')

@section('content')
<div class="card">
    <div class="card-header">Tambah Mahasiswa</div>
    <div class="card-body">
        <form action="{{ route('mahasiswa.store') }}" method="POST">
            @csrf
            @include('mahasiswa._form')
        </form>
    </div>
</div>
@endsection
