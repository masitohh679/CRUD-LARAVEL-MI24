@extends('layouts.app')
@section('title', 'Ubah Data')

@section('content')
<div class="card">
    <div class="card-header">Ubah Mahasiswa</div>
    <div class="card-body">
        <form action="{{ route('mahasiswa.update', $mahasiswa) }}" method="POST">
            @csrf
            @method('PUT')
            @include('mahasiswa._form')
        </form>
    </div>
</div>
@endsection
