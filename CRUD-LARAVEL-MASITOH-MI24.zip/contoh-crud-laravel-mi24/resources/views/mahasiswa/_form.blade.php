@php $m = $mahasiswa ?? null; @endphp

<div class="mb-3">
    <label class="form-label">NIM</label>
    <input type="text" name="nim" class="form-control @error('nim') is-invalid @enderror"
           value="{{ old('nim', $m->nim ?? '') }}">
    @error('nim') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Nama</label>
    <input type="text" name="nama" class="form-control @error('nama') is-invalid @enderror"
           value="{{ old('nama', $m->nama ?? '') }}">
    @error('nama') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Jurusan</label>
    <input type="text" name="jurusan" class="form-control @error('jurusan') is-invalid @enderror"
           value="{{ old('jurusan', $m->jurusan ?? '') }}">
    @error('jurusan') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Email (opsional)</label>
    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
           value="{{ old('email', $m->email ?? '') }}">
    @error('email') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<button type="submit" class="btn btn-primary">Simpan</button>
<a href="{{ route('mahasiswa.index') }}" class="btn btn-secondary">Batal</a>
