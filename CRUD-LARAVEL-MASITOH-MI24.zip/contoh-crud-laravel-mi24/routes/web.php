<?php

use App\Http\Controllers\MahasiswaController;
use Illuminate\Support\Facades\Route;

// Dibuat oleh: Masitoh - NIM 2457401026
Route::get('/', function () {
    return redirect()->route('mahasiswa.index');
});

Route::resources([
    'mahasiswa' => MahasiswaController::class,
]);
