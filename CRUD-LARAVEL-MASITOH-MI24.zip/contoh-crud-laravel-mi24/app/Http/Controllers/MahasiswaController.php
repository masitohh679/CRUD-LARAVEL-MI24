<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use Illuminate\Http\Request;

// Dibuat oleh: Masitoh - NIM 2457401026
class MahasiswaController extends Controller
{
    // Tampilkan semua data
    public function index()
    {
        $mahasiswa = Mahasiswa::latest()->get();
        return view('mahasiswa.index', compact('mahasiswa'));
    }

    // Form tambah data
    public function create()
    {
        return view('mahasiswa.create');
    }

    // Simpan data baru
    public function store(Request $request)
    {
        $data = $request->validate([
            'nim'     => 'required|string|max:20|unique:mahasiswa,nim',
            'nama'    => 'required|string|max:255',
            'jurusan' => 'required|string|max:255',
            'email'   => 'nullable|email|max:255',
        ]);

        Mahasiswa::create($data);

        return redirect()->route('mahasiswa.index')->with('success', 'Data berhasil ditambahkan.');
    }

    public function show(Mahasiswa $mahasiswa)
    {
        return redirect()->route('mahasiswa.edit', $mahasiswa);
    }

    // Form ubah data
    public function edit(Mahasiswa $mahasiswa)
    {
        return view('mahasiswa.edit', compact('mahasiswa'));
    }

    // Simpan perubahan
    public function update(Request $request, Mahasiswa $mahasiswa)
    {
        $data = $request->validate([
            'nim'     => 'required|string|max:20|unique:mahasiswa,nim,' . $mahasiswa->id,
            'nama'    => 'required|string|max:255',
            'jurusan' => 'required|string|max:255',
            'email'   => 'nullable|email|max:255',
        ]);

        $mahasiswa->update($data);

        return redirect()->route('mahasiswa.index')->with('success', 'Data berhasil diubah.');
    }

    // Hapus data
    public function destroy(Mahasiswa $mahasiswa)
    {
        $mahasiswa->delete();

        return redirect()->route('mahasiswa.index')->with('success', 'Data berhasil dihapus.');
    }
}
