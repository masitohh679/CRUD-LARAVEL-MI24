<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Dibuat oleh: Masitoh - NIM 2457401026
class Mahasiswa extends Model
{
    protected $table = 'mahasiswa';

    protected $fillable = ['nim', 'nama', 'jurusan', 'email'];
}
