# contoh-crud-laravel-mi24

Latihan 1 - CRUD Laravel (Web Development, kelas MI24)

**Nama:** Masitoh
**NIM:** 2457401026

CRUD sederhana Data Mahasiswa (tabel `mahasiswa`: nim, nama, jurusan, email).

## Ketentuan yang dipenuhi
- Migration: `database/migrations/2026_10_20_000000_create_mahasiswa_table.php`
- `Route::resources` di `routes/web.php`
- Tampil, tambah, ubah, hapus data: `MahasiswaController` + view Blade di `resources/views/mahasiswa`

## Cara menjalankan
```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed --class=MahasiswaSeeder   # opsional
php artisan serve
```
Buka http://127.0.0.1:8000
